package edu.java.homework;

public class MyCircle {

	double radius;
	
	// 기본 생성자 생성
	public MyCircle() {
		
	}
	// 매개변수(double radius)가 있는 생성자
	public MyCircle(double radius) {
		this.radius = radius ;
		
	}
	
	// 메소드
	
	public double calcArea() {
		return 3.14*radius*radius;
		
		
	}

} // end MyCircle
