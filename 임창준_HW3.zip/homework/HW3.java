package edu.java.homework;



public class HW3 {

	public static void main(String[] args) {
		
		// MyCircle 인스턴스를 생성
		MyCircle rect1 = new MyCircle();
		
		rect1.radius = 2.0;
		
		System.out.println("반지름 : " + rect1.radius);
		System.out.println("면적 : " +rect1.calcArea() );
		MyCircle rect2 = new MyCircle(2.0);
		System.out.println("반지름 : " + rect2.radius);
		System.out.println("면적 : " + rect2.calcArea());
		
		
		
		
	} // end main()

} // end HW3
