package edu.java.homework;

public class Printer {

public void println(int result) {
	System.out.println(result);
	
}

public void println(double result) {
	System.out.println(result);
	
}

public void println(boolean result) {
	System.out.println(result);
	
}

public void println(String result) {
	System.out.println(result);
	
}
} // end Printer
